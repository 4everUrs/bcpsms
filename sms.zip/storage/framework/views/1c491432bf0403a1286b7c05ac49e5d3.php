<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employeeDashboard')); ?>">
                <i class="ri ri-dashboard-fill"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('attendance')); ?>">
                <i class="ri ri-dashboard-fill"></i>
                <span>Attendance</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('eleave')); ?>">
                <i class="ri ri-dashboard-fill"></i>
                <span>Leave Management</span>
            </a>
        </li>
        
    </ul>

</aside><!-- End Sidebar--><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/layouts/employee-sidebar.blade.php ENDPATH**/ ?>