<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title',

]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title',

]); ?>
<?php foreach (array_filter(([
    'title',

]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($title); ?></h5>
        <div class="row mb-3">
            <div class="col-3">
                <div class="input-group">
                    <span class="input-group-text">Showing</span>
                    <select class="form-select">
                        <option value="5">5</option>
                    </select>
                    <span class="input-group-text">Entries</span>
                </div>
            </div>
            <div class="col"></div>
            <div class="col-3">
                <div class="input-group float-end">
                    <input type="text" class="form-control" placeholder="Search">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                </div>
            </div>
        </div>
        <table class="table table-sm table-striped">
            <?php echo e($slot); ?>

        </table>
    </div>
</div><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/components/table.blade.php ENDPATH**/ ?>