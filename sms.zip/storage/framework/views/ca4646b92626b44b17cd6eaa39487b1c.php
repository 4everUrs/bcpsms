<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Payroll</h1>
     <?php $__env->endSlot(); ?>
    <button class="btn btn-success mb-3" data-toggle="modal" data-target="#newPayroll">+ New Payroll</button>
    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Payroll']); ?>
        <thead>
            <th>Month</th>
            <th>From</th>
            <th>To</th>
            <th></th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($payroll->MonthlyAttendance->month); ?></td>
                    <td><?php echo e($payroll->CutoffAttendance->start); ?></td>
                    <td><?php echo e($payroll->CutoffAttendance->end); ?></td>
                    <td class="text-center">
                        <a wire:click="getID(<?php echo e($payroll->id); ?>)" href="#data<?php echo e($index); ?>" data-toggle="collapse"><i class="bi bi-arrows-expand"></i></a>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <div class="collapse p-4" id="data<?php echo e($index); ?>" wire:ignore.self>
                            
                            <div class="card p-3">
                                
                                <div class="card-body">
                                    <button class="btn btn-sm btn-success"> <i class="bi bi-file-earmark-pdf-fill"></i> Export</button>
                                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#importData"> <i class="bi bi-download"></i> Import Attendance</button>
                                    <button class="btn btn-sm btn-secondary"> <i class="bi bi-telegram"></i> Send Payslip</button>
                                    <table class="table table-sm table-striped">
                                        <thead>
                                            <th class="text-center">Employee ID</th>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Total Hours</th>
                                            <th class="text-center">Net Salary</th>
                                            <th class="text-center">Benefits</th>
                                            <th class="text-center">Tax</th>
                                            <th class="text-center">Overtime</th>
                                            <th class="text-center">Gross Salary</th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $payslips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payslip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center align-middle"><?php echo e($payslip->employee_id); ?></td>
                                                    <td class="text-center align-middle"><?php echo e($payslip->CutoffAttendance->start); ?> - <?php echo e($payslip->CutoffAttendance->end); ?></td>
                                                    <td class="text-center align-middle"><?php echo e($payslip->Employee->name); ?></td>
                                                    <td class="text-center align-middle"><?php echo e($payslip->total_hours); ?></td>
                                                    <td class="text-center align-middle"><?php echo '₱ ' . number_format($payslip->net_salary, 2); ?></td>
                                                    <td class=" align-middle">
                                                        <ul>
                                                            <li>SSS: <?php echo e($payslip->sss); ?></li>
                                                            <li>Philhealth: <?php echo e($payslip->philhealth); ?></li>
                                                            <li>Pagibig: <?php echo e($payslip->pagibig); ?></li>
                                                        </ul>
                                                    </td>
                                                    <td class="text-center align-middle"><?php echo '₱ ' . number_format($payslip->tax, 2); ?></td>
                                                    <td class="text-center align-middle"><?php echo '₱ ' . number_format($payslip->over_time, 2); ?></td>
                                                    <td class="text-center align-middle"><?php echo '₱ ' . number_format($payslip->gross_salary, 2); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'newPayroll']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'newPayroll']); ?>
         <?php $__env->slot('head', null, []); ?> Add Payroll <?php $__env->endSlot(); ?>

         <?php $__env->slot('body', null, []); ?> 
            <label>Month</label>
            <select class="form-select" wire:model="month">
                <option value="">Choose...</option>
                <?php $__currentLoopData = $monthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($month->id); ?>"><?php echo e($month->month); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Date</label>
            <select class="form-select">
                <option value="">Choose...</option>
               <?php if(!empty($cutoffs)): ?>
                    <?php $__currentLoopData = $cutoffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cutoff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=""><?php echo e($cutoff->start); ?> - <?php echo e($cutoff->end); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
                   
               <?php endif; ?>
            </select>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-button','data' => ['wire:click' => 'addPayroll']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'addPayroll']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'importData']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'importData']); ?>
         <?php $__env->slot('head', null, []); ?> Import Attendance <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <h1>Are you sure?</h1>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-button','data' => ['wire:click' => 'createPayslip']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'createPayslip']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <script>
        window.addEventListener('close-payslip-modal',event=>{
        $("#importData").removeClass("in");
        $(".modal-backdrop").remove();
        $("#importData").hide();
        })
        window.addEventListener('close-payroll-modal',event=>{
        $("#newPayroll").removeClass("in");
        $(".modal-backdrop").remove();
        $("#newPayroll").hide();
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr2/payroll.blade.php ENDPATH**/ ?>