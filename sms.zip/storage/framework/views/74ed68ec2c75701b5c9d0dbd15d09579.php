<!DOCTYPE html>
<html lang="en">

    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<body>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header')->html();
} elseif ($_instance->childHasBeenRendered('YXESE8X')) {
    $componentId = $_instance->getRenderedChildComponentId('YXESE8X');
    $componentTag = $_instance->getRenderedChildComponentTagName('YXESE8X');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YXESE8X');
} else {
    $response = \Livewire\Livewire::mount('header');
    $html = $response->html();
    $_instance->logRenderedChild('YXESE8X', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   
    <?php if(Auth::user()->user_level == 0): ?>
        <?php echo $__env->make('layouts.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->user_level == 1): ?>
        <?php echo $__env->make('layouts.hr1-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->user_level == 2): ?>
        <?php echo $__env->make('layouts.hr2-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->user_level == 3): ?>
        <?php echo $__env->make('layouts.employee-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    

    <?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/layouts/app.blade.php ENDPATH**/ ?>