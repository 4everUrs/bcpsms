<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Attendance</h1>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Attendance']); ?>
        <thead>
            <th class="text-center align-middle">No</th>
            <th class="text-center align-middle">Date</th>
            <th class="text-center align-middle">Time In</th>
            <th class="text-center align-middle">Time Out</th>
            <th class="text-center align-middle">Rendered Hours</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center align-middle"><?php echo e($index+1); ?></td>
                    <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($attendance->created_at)->toFormattedDateString()?></td>
                    <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($attendance->time_in)->format('g:i:A')?></td>
                    <?php if($attendance->time_out): ?>
                        <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($attendance->time_out)->format('g:i:A')?></td>
                    <?php else: ?>
                        <td class="text-center align-middle"></td>
                    <?php endif; ?>
                    <td class="text-center align-middle"><?php echo e($attendance->rendered_hours); ?> Hours</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>  
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/employee/attendance.blade.php ENDPATH**/ ?>