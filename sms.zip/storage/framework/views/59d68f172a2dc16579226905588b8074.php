

<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
<button  <?php echo $attributes->merge(['class' => 'btn btn-primary','type'=>'button']); ?>>Save changes</button><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/components/modal-button.blade.php ENDPATH**/ ?>