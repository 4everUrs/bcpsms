<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Perfomance Management</h1>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Employees']); ?>
        <thead>
            <th class="text-center align-middle">Employee ID</th>
            <th class="text-center align-middle">Position</th>
            <th class="text-center align-middle">Name</th>
            <th class="text-center align-middle">Quality</th>
            <th class="text-center align-middle">Achievement</th>
            <th class="text-center align-middle">Productivity</th>
            <th class="text-center align-middle">Initiative</th>
            <th class="text-center align-middle">Teamwork</th>
            <th class="text-center align-middle">Adaptability</th>
            <th class="text-center align-middle">Communication</th>
            <th class="text-center align-middle">Performance</th>
            <th class="text-center align-middle">Remarks</th>
            <th class="text-center align-middle">Action</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $performances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfomance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center align-middle"><?php echo e($perfomance->employee_id); ?></td>
                    <td class="text-center align-middle"><?php echo e($perfomance->Employee->Vacancy->position); ?></td>
                    <td class="text-center align-middle"><?php echo e($perfomance->Employee->name); ?></td>
                    <?php if($perfomance->quality == '60'): ?>
                        <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->quality == '70'): ?>
                        <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->quality == '80'): ?>
                        <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->quality == '90'): ?>
                        <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->quality == '100'): ?>
                        <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->achievement == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->achievement == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->achievement == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->achievement == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->achievement == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->productivity == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->productivity == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->productivity == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->productivity == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->productivity == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->initiative == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->initiative == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->initiative == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->initiative == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->initiative == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->teamwork == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->teamwork == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->teamwork == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->teamwork == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->teamwork == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->adaptability == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->adaptability == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->adaptability == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->adaptability == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->adaptability == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->communication == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->communication == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->communication == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->communication == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->communication == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if($perfomance->performance == '60'): ?>
                    <td class="text-center align-middle text-danger">Bad</td>
                    <?php elseif($perfomance->performance == '70'): ?>
                    <td class="text-center align-middle text-warning">Poor</td>
                    <?php elseif($perfomance->performance == '80'): ?>
                    <td class="text-center align-middle text-primary">Average</td>
                    <?php elseif($perfomance->performance == '90'): ?>
                    <td class="text-center align-middle text-success">Good</td>
                    <?php elseif($perfomance->performance == '100'): ?>
                    <td class="text-center align-middle text-success">Excellent</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                    <td class="text-center align-middle"><?php echo e($perfomance->remarks); ?></td>
                    <td class="text-center align-middle">
                        <button wire:click="getId(<?php echo e($perfomance->id); ?>)" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#evaluationModal">Evaluate</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'evaluationModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'evaluationModal']); ?>
         <?php $__env->slot('head', null, []); ?> Evaluation Form <?php $__env->endSlot(); ?>

         <?php $__env->slot('body', null, []); ?> 
            <label>Quality</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check"> 
                        <input class="form-check-input" type="radio" wire:model="quality" id="quality1" value="60"> 
                        <label class="form-check-label" for="quality1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="quality" id="quality2" value="70">
                        <label class="form-check-label" for="quality2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="quality" id="quality3" value="80">
                        <label class="form-check-label" for="quality3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="quality" id="quality4" value="90">
                        <label class="form-check-label" for="quality4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="quality" id="quality5" value="100">
                        <label class="form-check-label" for="quality5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Achievement</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check"> 
                        <input class="form-check-input" type="radio" wire:model="achievement" id="achievement1" value="60"> 
                        <label class="form-check-label" for="achievement1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="achievement" id="achievement2" value="70">
                        <label class="form-check-label" for="achievement2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="achievement" id="achievement3" value="80">
                        <label class="form-check-label" for="achievement3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="achievement" id="achievement4" value="90">
                        <label class="form-check-label" for="achievement4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="achievement" id="achievement5" value="100">
                        <label class="form-check-label" for="achievement5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Productivity</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="productivity" id="productivity1" value="60">
                        <label class="form-check-label" for="productivity1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="productivity" id="productivity2" value="70">
                        <label class="form-check-label" for="productivity2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="productivity" id="productivity3" value="80">
                        <label class="form-check-label" for="productivity3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="productivity" id="productivity4" value="90">
                        <label class="form-check-label" for="productivity4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="productivity" id="productivity5" value="100">
                        <label class="form-check-label" for="productivity5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Initiative</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="initiative" id="initiative1" value="60">
                        <label class="form-check-label" for="initiative1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="initiative" id="initiative2" value="70">
                        <label class="form-check-label" for="initiative2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="initiative" id="initiative3" value="80">
                        <label class="form-check-label" for="initiative3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="initiative" id="initiative4" value="90">
                        <label class="form-check-label" for="initiative4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="initiative" id="initiative5" value="100">
                        <label class="form-check-label" for="initiative5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Teamwork</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="teamwork" id="teamwork1" value="60">
                        <label class="form-check-label" for="teamwork1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="teamwork" id="teamwork2" value="70">
                        <label class="form-check-label" for="teamwork2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="teamwork" id="teamwork3" value="80">
                        <label class="form-check-label" for="teamwork3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="teamwork" id="teamwork4" value="90">
                        <label class="form-check-label" for="teamwork4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="teamwork" id="teamwork5" value="100">
                        <label class="form-check-label" for="teamwork5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Adaptability</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="adaptability" id="adaptability1" value="60">
                        <label class="form-check-label" for="adaptability1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="adaptability" id="adaptability2" value="70">
                        <label class="form-check-label" for="adaptability2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="adaptability" id="adaptability3" value="80">
                        <label class="form-check-label" for="adaptability3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="adaptability" id="adaptability4" value="90">
                        <label class="form-check-label" for="adaptability4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="adaptability" id="adaptability5" value="100">
                        <label class="form-check-label" for="adaptability5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Communication</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="communication" id="communication1" value="60">
                        <label class="form-check-label" for="communication1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="communication" id="communication2" value="70">
                        <label class="form-check-label" for="communication2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="communication" id="communication3" value="80">
                        <label class="form-check-label" for="communication3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="communication" id="communication4" value="90">
                        <label class="form-check-label" for="communication4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="communication" id="communication5" value="100">
                        <label class="form-check-label" for="communication5"> Excellent </label>
                    </div>
                </div>
            </div>

            <label>Performance</label>
            <div class="row mb-3">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="performance" id="performance1" value="60">
                        <label class="form-check-label" for="performance1"> Bad </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="performance" id="performance2" value="70">
                        <label class="form-check-label" for="performance2"> Poor </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="performance" id="performance3" value="80">
                        <label class="form-check-label" for="performance3"> Average </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="performance" id="performance4" value="90">
                        <label class="form-check-label" for="performance4"> Good </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" wire:model="performance" id="performance5"
                            value="100">
                        <label class="form-check-label" for="performance5"> Excellent </label>
                    </div>
                </div>
            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-button','data' => ['wire:click' => 'saveEvaluation']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'saveEvaluation']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <script>
        window.addEventListener('close-modal',event=>{
            $("#evaluationModal").removeClass("in");
            $(".modal-backdrop").remove();
            $("#evaluationModal").hide();
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr1/performance-management.blade.php ENDPATH**/ ?>