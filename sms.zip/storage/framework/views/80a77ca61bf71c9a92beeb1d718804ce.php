<main id="main" class="main">

    <div class="pagetitle">
        <h1><?php echo e($header); ?></h1>
    </div><!-- End Page Title -->

    <section class="section dashboard p-3">
        <?php echo e($slot); ?>

    </section>

</main><!-- End #main --><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/layouts/content.blade.php ENDPATH**/ ?>