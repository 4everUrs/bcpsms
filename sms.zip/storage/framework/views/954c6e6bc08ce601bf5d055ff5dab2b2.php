<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Requests List</h1>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Requests']); ?>
        <thead>
            <th class="text-center">No</th>
            <th class="text-center">Position</th>
            <th class="text-center">Slot</th>
            <th class="text-center">Salary</th>
            <th class="text-center">Action</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($index+1); ?></td>
                    <td class="text-center"><?php echo e($request->position); ?></td>
                    <td class="text-center"><?php echo e($request->slot); ?></td>
                    <td class="text-center"><?php echo e($request->salary_min); ?> - <?php echo e($request->salary_max); ?></td>
                    <td class="text-center">
                        <button class="btn btn-primary btn-sm">Approve</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr1/recruitment-request.blade.php ENDPATH**/ ?>