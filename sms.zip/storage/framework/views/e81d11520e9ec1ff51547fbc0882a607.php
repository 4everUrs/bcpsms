<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>HR1-Dashboard</h1>
     <?php $__env->endSlot(); ?>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr1-dashboard.blade.php ENDPATH**/ ?>