<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>TimeSheet Management</h1>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Attendance']); ?>
        <thead>
            <th class="">Month</th>
            <th class="">Year</th>
            <th></th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(Carbon\Carbon::parse($month->month)->format('F')); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($month->month)->format('Y')); ?></td>
                <td style="width: 10%">
                    <a href="#collapseExample" data-toggle="collapse"><i class="bi bi-arrows-expand"></i></a>
                </td>
            </tr>
            <tr >
                <td colspan="3">
                    <div class="collapse" id="collapseExample" wire:ignore.self>
                        <table class="table table-striped">
                            <thead>
                                <th>From</th>
                                <th>To</th>
                                <th></th>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $month->Cutoff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cutoff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                        <td><?php echo e($cutoff->start); ?></td>
                                        <td><?php echo e($cutoff->end); ?></td>
                                        <td>
                                            <a wire:click="getData(<?php echo e($cutoff->id); ?>)" href="#cutoff<?php echo e($index); ?>" data-toggle="collapse"><i class="bi bi-arrows-expand"></i></a>   
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <div class="collapse" id="cutoff<?php echo e($index); ?>">
                                                <button class="btn btn-success btn-sm">Export</button>
                                                <div class="card card-body p-4">
                                                    
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <th class="text-center align-middle">Date</th>
                                                            <th class="text-center align-middle">ID No</th>
                                                            <th class="text-center align-middle">Name</th>
                                                            <th class="text-center align-middle">Time In</th>
                                                            <th class="text-center align-middle">Time Out</th>
                                                            <th class="text-center align-middle">Rendered Hours</th>
                                                        </thead>
                                                        <tbody>
                                                           <?php if($attendances): ?>
                                                               <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <tr>
                                                                    <td class="text-center"><?php echo Carbon\Carbon::parse($attendance->created_at)->toFormattedDateString()?></td>
                                                                    <td class="text-center"><?php echo e($attendance->employee_id); ?></td>
                                                                    <td class="text-center"><?php echo e($attendance->Employee->name); ?></td>
                                                                    <td class="text-center"><?php echo Carbon\Carbon::parse($attendance->time_in)->format('g:i:A')?></td>
                                                                    <?php if($attendance->time_out): ?>
                                                                        <td class="text-center"><?php echo Carbon\Carbon::parse($attendance->time_out)->format('g:i:A')?></td>
                                                                    <?php else: ?>
                                                                        <td class="text-center">--/---/--</td>
                                                                    <?php endif; ?>
                                                                    
                                                                    <td class="text-center"><?php echo e($attendance->rendered_hours); ?> Hours</td>
                                                                </tr>
                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr2/time-and-attendance.blade.php ENDPATH**/ ?>