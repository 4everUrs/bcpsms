<!-- Vendor JS Files -->
<script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>

<script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/chart.js/chart.umd.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/echarts/echarts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/quill/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('#sidenav a').filter(function(){
        return this.href == window.location.href;
        }).parent().removeClass('collapsed');
    });
</script>
<!-- Template Main JS File -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>