<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name','id',
    'show' => true,
    'maxWidth' => 'md'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name','id',
    'show' => true,
    'maxWidth' => 'md'
]); ?>
<?php foreach (array_filter(([
    'name','id',
    'show' => true,
    'maxWidth' => 'md'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="modal fade modal-<?php echo e($maxWidth); ?>" id="<?php echo e($id); ?>" tabindex="-1" wire:ignore.self>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($head); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($body); ?>

            </div>
            <div class="modal-footer">
                <?php echo e($footer); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/components/modal.blade.php ENDPATH**/ ?>