<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
        <?php $__env->startSection('hr1-sidebar'); ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('hr1Dashboard')); ?>">
                <i class="ri ri-dashboard-fill"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-gem"></i><span>Recruitment</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="<?php echo e(route('recruitment-request')); ?>">
                        <i class="bi bi-circle"></i><span>Request List</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('recruitment')); ?>">
                        <i class="bi bi-circle"></i><span>Recruitment</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('recruitment')); ?>">
                <i class="bi bi-person-lines-fill"></i><span>Recruitment</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('applicant')); ?>">
                <i class="bi bi-person-badge"></i><span>Applicant Management</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('onboarding')); ?>">
                <i class="bi bi-person-badge"></i><span>New Hire on Board</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#">
                <i class="bi bi-person-badge"></i><span>Social Recognition</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#">
                <i class="bi bi-person-badge"></i><span>Compentency Management</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('performance')); ?>">
                <i class="bi bi-person-badge"></i><span>Performance Management</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#">
                <i class="bi bi-person-badge"></i><span>Succession Planning</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('learning')); ?>">
                <i class="bi bi-person-badge"></i><span>Learning / Training Management</span>
            </a>
        </li>
        <?php $__env->stopSection(); ?>
     
        
        
        
        
        
    </ul>

</aside><!-- End Sidebar--><?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/layouts/hr1-sidebar.blade.php ENDPATH**/ ?>