<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Learning / Training Management</h1>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Learning / Training']); ?>
        <thead>
            <th class="text-center align-middle">No</th>
            <th class="text-center align-middle">Position</th>
            <th class="text-center align-middle">Name</th>
            <th class="text-center align-middle">Age</th>
            <th class="text-center align-middle">Gender</th>
            <th class="text-center align-middle">Resume</th>
            <th class="text-center align-middle">Exam</th>
            <th class="text-center align-middle">Training</th>
            <th class="text-center align-middle">Remarks</th>
            <th class="text-center align-middle">Action</th>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center align-middle"><?php echo e($index+1); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->Candidate->Vacancy->position); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->Candidate->name); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->Candidate->age); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->Candidate->gender); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->Candidate->resume); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->exam); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->training); ?></td>
                    <td class="text-center align-middle"><?php echo e($training->remarks); ?></td>
                    <td class="text-center align-middle">
                        <button wire:click='getId(<?php echo e($training->id); ?>)' class="btn btn-primary btn-sm" data-toggle="modal" data-target="#evaluate">Evaluate</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'evaluate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'evaluate']); ?>
         <?php $__env->slot('head', null, []); ?> Evaluation <?php $__env->endSlot(); ?>

         <?php $__env->slot('body', null, []); ?> 
            <div class="form-group">
                <label>Exam</label>
                <div class="row">
                    <div class="col">
                        <div class="form-check"> <input id="gridRadios1" wire:model='exam' class="form-check-input" type="radio" value="Passed" checked="">
                            <label class="form-check-label" for="gridRadios1"> Passed </label></div>
                    </div>
                    <div class="col">
                        <div class="form-check"> <input id="gridRadios11" wire:model='exam' class="form-check-input" type="radio" value="Failed" checked="">
                            <label class="form-check-label" for="gridRadios11"> Failed </label></div>
                    </div>
                </div>
                <label>Training</label>
                <div class="row">
                    <div class="col">
                        <div class="form-check"> <input id="gridRadios12" wire:model='training' class="form-check-input" type="radio" value="Passed"
                                checked="">
                            <label class="form-check-label" for="gridRadios12"> Passed </label>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-check"> <input id="gridRadios13" wire:model='training' class="form-check-input" type="radio" value="Failed"
                                checked="">
                            <label class="form-check-label" for="gridRadios13"> Failed </label>
                        </div>
                    </div>
                </div>
            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-button','data' => ['wire:click' => 'evaluate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'evaluate']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <script>
        window.addEventListener('close-modal',event=>{
            $("#evaluate").removeClass("in");
            $(".modal-backdrop").remove();
            $("#evaluate").hide();
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/hr1/learning-management.blade.php ENDPATH**/ ?>