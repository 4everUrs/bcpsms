<div>
     <?php $__env->slot('header', null, []); ?> 
        <h1>Employee Dashboard</h1>
     <?php $__env->endSlot(); ?>

    
</div>
<?php /**PATH C:\Users\romel\Desktop\School Management System\sms\resources\views/livewire/employee/employee.blade.php ENDPATH**/ ?>