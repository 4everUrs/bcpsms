@props(['messages','model'])

@error($model) <span class="text-danger">{{ $message }}<br></span> @enderror
