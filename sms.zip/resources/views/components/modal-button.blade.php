

<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
<button  {!! $attributes->merge(['class' => 'btn btn-primary','type'=>'button']) !!}>Save changes</button>