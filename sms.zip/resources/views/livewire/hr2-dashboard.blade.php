<div>
    <x-slot name="header">
        <h1>HR-2 Dashboard</h1>
    </x-slot>
</div>
