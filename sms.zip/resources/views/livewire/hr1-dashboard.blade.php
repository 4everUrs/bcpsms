<div>
    <x-slot name="header">
        <h1>HR1-Dashboard</h1>
    </x-slot>
</div>
