<div>
    <x-slot name="header">
        <h1>Employee Dashboard</h1>
    </x-slot>

    
</div>
