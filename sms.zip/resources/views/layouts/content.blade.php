<main id="main" class="main">

    <div class="pagetitle">
        <h1>{{$header}}</h1>
    </div><!-- End Page Title -->

    <section class="section dashboard p-3">
        {{$slot}}
    </section>

</main><!-- End #main -->