<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Hr1Dashboard extends Component
{
    public function render()
    {
        return view('livewire.hr1-dashboard');
    }
}
