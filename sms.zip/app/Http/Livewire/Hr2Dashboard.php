<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Hr2Dashboard extends Component
{
    public function render()
    {
        return view('livewire.hr2-dashboard');
    }
}
